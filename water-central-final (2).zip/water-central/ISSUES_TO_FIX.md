# Issues Found During Testing

## Translation Issues (Still in Spanish when EN is selected)
1. BenefitsSection "Water Transformation" comparison - items still in Spanish:
   - "Cloro y quimicos" should be "Chlorine & chemicals"
   - "Metales pesados" should be "Heavy metals"
   - "Bacterias y virus" should be "Bacteria & viruses"
   - "Sabor desagradable" should be "Bad taste"
   - "100% pura y cristalina" should be "100% pure & crystal clear"
   - "Libre de contaminantes" should be "Free from contaminants"
   - "Rica en minerales esenciales" should be "Rich in essential minerals"
   - "Sabor fresco y natural" should be "Fresh & natural taste"
   - "Agua pura" image alt still in Spanish

2. ContactFormExpanded - email placeholder "tu@email.com" should be "your@email.com"

## Need to verify
- Products carousel with tank images
- Brochure viewer modal
- CTA section translation
- Footer translation
