import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Play, CheckCircle } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function VSLSection() {
  const { t, language } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const benefits = [
    language === 'es' ? 'Descubre qué contaminantes están en tu agua' : 'Discover what contaminants are in your water',
    language === 'es' ? 'Cómo Water Central elimina el 100% de toxinas' : 'How Water Central eliminates 100% of toxins',
    language === 'es' ? 'Por qué 250K+ familias confían en nosotros' : 'Why 250K+ families trust us',
    language === 'es' ? 'Ahorra dinero eliminando botellas de plástico' : 'Save money by eliminating plastic bottles',
  ];

  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Video Section */}
          <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`}>
            <div className="relative group">
              {/* Video Container */}
              <div className="relative w-full aspect-video bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl overflow-hidden shadow-premium-lg border border-gray-200">
                {/* Video Placeholder */}
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative">
                  <iframe
                    width="100%"
                    height="100%"
                    src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=0"
                    title="Water Central - Video Sales Letter"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                  ></iframe>
                </div>

                {/* Play Button Overlay (if not using iframe) */}
                {!isPlaying && (
                  <button
                    onClick={() => setIsPlaying(true)}
                    className="absolute inset-0 flex items-center justify-center bg-black/40 hover:bg-black/50 transition-all duration-300 group opacity-0 group-hover:opacity-100"
                  >
                    <div className="w-20 h-20 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full flex items-center justify-center shadow-glow-lg hover:shadow-glow-lg transition-all hover:scale-110">
                      <Play size={32} className="text-white fill-white ml-1" />
                    </div>
                  </button>
                )}

                {/* Glow Effect */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-500/20 to-blue-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              {/* Video Badge */}
              <div className="absolute -bottom-4 -right-4 bg-gradient-to-r from-cyan-500 to-blue-600 text-white px-6 py-3 rounded-full font-bold shadow-glow-lg animate-pulse">
                {language === 'es' ? '3:45 min' : '3:45 min'}
              </div>
            </div>
          </div>

          {/* Content Section */}
          <div className={`transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/20 border border-cyan-500/50 rounded-full mb-6">
              <span className="text-cyan-600 font-semibold text-sm">
                {language === 'es' ? '▶ Mira este video' : '▶ Watch this video'}
              </span>
            </div>

            <h2 className="font-display text-5xl md:text-6xl font-bold text-primary mb-6 leading-tight">
              {language === 'es'
                ? 'Por Qué Tu Agua No Es Segura'
                : 'Why Your Water Is Not Safe'}
            </h2>

            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              {language === 'es'
                ? 'En este video de 3 minutos, nuestro experto en purificación de agua te muestra exactamente qué contaminantes están en el agua de tu hogar y cómo Water Central los elimina de forma permanente.'
                : 'In this 3-minute video, our water purification expert shows you exactly what contaminants are in your home\'s water and how Water Central eliminates them permanently.'}
            </p>

            {/* Benefits List */}
            <div className="space-y-4 mb-8">
              {benefits.map((benefit, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-all duration-300 group"
                >
                  <CheckCircle className="w-6 h-6 text-cyan-500 flex-shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
                  <span className="text-foreground font-medium group-hover:text-accent transition-colors">
                    {benefit}
                  </span>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-6 text-lg font-semibold border-0 shadow-glow-lg hover:shadow-glow-lg transition-all duration-300 hover:scale-105 w-full sm:w-auto">
              {language === 'es' ? '🎬 Ver Video Completo' : '🎬 Watch Full Video'}
            </Button>

            {/* Trust Badge */}
            <p className="text-sm text-muted-foreground mt-6">
              {language === 'es'
                ? '✓ Certificado por NSF/WQA • Confianza de 250K+ familias • Soporte 24/7'
                : '✓ Certified by NSF/WQA • Trusted by 250K+ families • 24/7 Support'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
