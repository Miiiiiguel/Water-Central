import { useState, useEffect, useCallback } from 'react';
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface Testimonial {
  id: number;
  name: string;
  role: { en: string; es: string };
  text: { en: string; es: string };
  rating: number;
  location: { en: string; es: string };
  image: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Sarah Johnson',
    role: { en: 'Mother of 3', es: 'Madre de 3 hijos' },
    text: {
      en: 'Water Central completely transformed our home water quality. My kids stopped getting stomach issues, and the water tastes incredible. Best investment we ever made for our family\'s health.',
      es: 'Water Central transformó completamente la calidad del agua en nuestro hogar. Mis hijos dejaron de tener problemas estomacales y el agua sabe increíble. La mejor inversión que hemos hecho para la salud de nuestra familia.',
    },
    rating: 5,
    location: { en: 'Houston, TX', es: 'Houston, TX' },
    image: 'https://i.pravatar.cc/150?img=47',
  },
  {
    id: 2,
    name: 'Michael Rodriguez',
    role: { en: 'Business Owner', es: 'Empresario' },
    text: {
      en: 'I installed the 10-stage system 6 months ago and the difference is night and day. No more scale buildup, no chlorine smell, and the service team was incredibly professional.',
      es: 'Instalé el sistema de 10 etapas hace 6 meses y la diferencia es abismal. No más acumulación de sarro, sin olor a cloro, y el equipo de servicio fue increíblemente profesional.',
    },
    rating: 5,
    location: { en: 'Dallas, TX', es: 'Dallas, TX' },
    image: 'https://i.pravatar.cc/150?img=12',
  },
  {
    id: 3,
    name: 'Dr. Emily Chen',
    role: { en: 'Pediatrician', es: 'Pediatra' },
    text: {
      en: 'As a pediatrician, I recommend Water Central to all my patients\' families. Clean water is the foundation of good health, especially for children. Their 10-stage filtration is the best I\'ve seen.',
      es: 'Como pediatra, recomiendo Water Central a todas las familias de mis pacientes. El agua limpia es la base de una buena salud, especialmente para los niños. Su filtración de 10 etapas es la mejor que he visto.',
    },
    rating: 5,
    location: { en: 'Austin, TX', es: 'Austin, TX' },
    image: 'https://i.pravatar.cc/150?img=32',
  },
  {
    id: 4,
    name: 'James & Lisa Thompson',
    role: { en: 'Retired Couple', es: 'Pareja Jubilada' },
    text: {
      en: 'At our age, health is everything. We noticed improvements in our skin, digestion, and overall energy within weeks. The installation was seamless and the team was so respectful of our home.',
      es: 'A nuestra edad, la salud lo es todo. Notamos mejoras en nuestra piel, digestión y energía general en semanas. La instalación fue impecable y el equipo fue muy respetuoso con nuestro hogar.',
    },
    rating: 5,
    location: { en: 'San Antonio, TX', es: 'San Antonio, TX' },
    image: 'https://i.pravatar.cc/150?img=60',
  },
  {
    id: 5,
    name: 'David Martinez',
    role: { en: 'Real Estate Agent', es: 'Agente Inmobiliario' },
    text: {
      en: 'I\'ve started recommending Water Central to all my homebuyers. It adds real value to any property and my clients love the peace of mind knowing their water is 100% pure.',
      es: 'He comenzado a recomendar Water Central a todos mis compradores de viviendas. Agrega valor real a cualquier propiedad y mis clientes aman la tranquilidad de saber que su agua es 100% pura.',
    },
    rating: 5,
    location: { en: 'Phoenix, AZ', es: 'Phoenix, AZ' },
    image: 'https://i.pravatar.cc/150?img=52',
  },
];

export default function TestimonialsCarousel() {
  const { language } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlay, setIsAutoPlay] = useState(true);
  const [isVisible, setIsVisible] = useState(false);
  const [touchStart, setTouchStart] = useState(0);
  const [touchEnd, setTouchEnd] = useState(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setIsVisible(true); },
      { threshold: 0.1 }
    );
    const el = document.getElementById('testimonials');
    if (el) observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isAutoPlay) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [isAutoPlay]);

  const goToPrevious = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
    setIsAutoPlay(false);
  }, []);

  const goToNext = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    setIsAutoPlay(false);
  }, []);

  // Touch handlers for mobile swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const minSwipeDistance = 50;
    if (Math.abs(distance) > minSwipeDistance) {
      if (distance > 0) goToNext();
      else goToPrevious();
    }
    setTouchStart(0);
    setTouchEnd(0);
  };

  const testimonial = testimonials[currentIndex];

  return (
    <section id="testimonials" className="py-16 md:py-24 lg:py-32 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-64 md:w-96 h-64 md:h-96 bg-cyan-500/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-0 left-0 w-64 md:w-96 h-64 md:h-96 bg-blue-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container relative z-10">
        {/* Header */}
        <div className={`text-center mb-10 md:mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-full mb-4 md:mb-6">
            <Star size={16} className="text-cyan-600 fill-cyan-600" />
            <span className="text-cyan-700 font-semibold text-sm">
              {language === 'es' ? 'Testimonios Verificados' : 'Verified Testimonials'}
            </span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-3 md:mb-4">
            {language === 'es' ? 'Lo Que Dicen Nuestros Clientes' : 'What Our Customers Say'}
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
            {language === 'es'
              ? 'Miles de familias confían en Water Central para su agua pura. Estas son sus historias reales.'
              : 'Thousands of families trust Water Central for their pure water. These are their real stories.'}
          </p>
        </div>

        {/* Carousel */}
        <div
          className={`relative max-w-4xl mx-auto transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {/* Testimonial Card */}
          <div className="relative min-h-[320px] sm:min-h-[280px] md:min-h-[260px]">
            {testimonials.map((t, index) => (
              <div
                key={t.id}
                className={`absolute inset-0 transition-all duration-700 ease-in-out ${
                  index === currentIndex
                    ? 'opacity-100 translate-x-0 z-10'
                    : index < currentIndex
                      ? 'opacity-0 -translate-x-full z-0'
                      : 'opacity-0 translate-x-full z-0'
                }`}
              >
                <div className="bg-white rounded-2xl p-6 sm:p-8 md:p-10 lg:p-12 shadow-premium-lg border border-gray-100 h-full flex flex-col justify-between relative overflow-hidden">
                  {/* Quote Icon */}
                  <div className="absolute top-4 right-4 md:top-6 md:right-6 opacity-10">
                    <Quote size={48} className="md:w-16 md:h-16 text-cyan-500" />
                  </div>

                  {/* Rating */}
                  <div className="flex gap-1 mb-3 md:mb-4">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} size={18} className="fill-yellow-400 text-yellow-400 md:w-5 md:h-5" />
                    ))}
                  </div>

                  {/* Text */}
                  <p className="text-base sm:text-lg md:text-xl text-foreground mb-4 md:mb-6 flex-grow italic leading-relaxed">
                    &ldquo;{language === 'es' ? t.text.es : t.text.en}&rdquo;
                  </p>

                  {/* Author */}
                  <div className="flex items-center gap-3 md:gap-4">
                    <img
                      src={t.image}
                      alt={t.name}
                      className="w-12 h-12 md:w-16 md:h-16 rounded-full border-2 border-cyan-500 object-cover"
                      loading="lazy"
                    />
                    <div>
                      <p className="font-bold text-foreground text-base md:text-lg">{t.name}</p>
                      <p className="text-xs md:text-sm text-muted-foreground">
                        {language === 'es' ? t.role.es : t.role.en} &bull; {language === 'es' ? t.location.es : t.location.en}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation Buttons - Hidden on very small screens, use swipe instead */}
          <button
            onClick={goToPrevious}
            className="hidden sm:flex absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-14 lg:-translate-x-20 z-20 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white p-2.5 md:p-3 rounded-full shadow-glow-lg hover:shadow-glow-lg transition-all duration-300 hover:scale-110 items-center justify-center"
            aria-label="Previous testimonial"
          >
            <ChevronLeft size={20} className="md:w-6 md:h-6" />
          </button>

          <button
            onClick={goToNext}
            className="hidden sm:flex absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-14 lg:translate-x-20 z-20 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white p-2.5 md:p-3 rounded-full shadow-glow-lg hover:shadow-glow-lg transition-all duration-300 hover:scale-110 items-center justify-center"
            aria-label="Next testimonial"
          >
            <ChevronRight size={20} className="md:w-6 md:h-6" />
          </button>

          {/* Dots Indicator + Swipe hint on mobile */}
          <div className="flex flex-col items-center gap-2 mt-6 md:mt-8">
            <div className="flex justify-center gap-2 md:gap-3">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => { setCurrentIndex(index); setIsAutoPlay(false); }}
                  className={`h-2.5 md:h-3 rounded-full transition-all duration-300 ${
                    index === currentIndex
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 w-6 md:w-8'
                      : 'bg-gray-300 w-2.5 md:w-3 hover:bg-gray-400'
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
            <p className="text-xs text-muted-foreground sm:hidden">
              {language === 'es' ? 'Desliza para ver más' : 'Swipe to see more'}
            </p>
          </div>
        </div>

        {/* Trust Badges */}
        <div className={`mt-12 md:mt-16 pt-6 md:pt-8 border-t border-gray-200 grid grid-cols-3 gap-4 md:gap-8 transition-all duration-700 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold text-cyan-600 mb-1 md:mb-2">250K+</div>
            <p className="text-xs md:text-sm text-muted-foreground">
              {language === 'es' ? 'Familias Satisfechas' : 'Satisfied Families'}
            </p>
          </div>
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold text-cyan-600 mb-1 md:mb-2">4.9/5</div>
            <p className="text-xs md:text-sm text-muted-foreground">
              {language === 'es' ? 'Calificación Promedio' : 'Average Rating'}
            </p>
          </div>
          <div className="text-center">
            <div className="text-2xl md:text-3xl font-bold text-cyan-600 mb-1 md:mb-2">99.9%</div>
            <p className="text-xs md:text-sm text-muted-foreground">
              {language === 'es' ? 'Satisfacción Garantizada' : 'Satisfaction Rate'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
