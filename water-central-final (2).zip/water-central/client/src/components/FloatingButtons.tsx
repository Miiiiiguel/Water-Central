import { useState, useEffect } from 'react';
import { Phone, MessageCircle, X, MessageSquare } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function FloatingButtons() {
  const { language } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [showPulse, setShowPulse] = useState(true);

  const phoneNumber = '+18007484189';
  const whatsappMessage = language === 'es'
    ? 'Hola, me interesa obtener información sobre los sistemas de purificación de agua Water Central.'
    : 'Hi, I\'m interested in getting information about Water Central water purification systems.';

  useEffect(() => {
    if (isOpen) setShowPulse(false);
  }, [isOpen]);

  const actions = [
    {
      icon: MessageCircle,
      label: 'WhatsApp',
      href: `https://wa.me/${phoneNumber}?text=${encodeURIComponent(whatsappMessage)}`,
      color: 'bg-green-500 hover:bg-green-600',
      ariaLabel: 'Chat on WhatsApp',
    },
    {
      icon: MessageSquare,
      label: language === 'es' ? 'SMS' : 'Text Us',
      href: `sms:${phoneNumber}?body=${encodeURIComponent(whatsappMessage)}`,
      color: 'bg-blue-500 hover:bg-blue-600',
      ariaLabel: 'Send a text message',
    },
    {
      icon: Phone,
      label: language === 'es' ? 'Llamar' : 'Call Now',
      href: `tel:${phoneNumber}`,
      color: 'bg-cyan-500 hover:bg-cyan-600',
      ariaLabel: 'Call us now',
    },
  ];

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/20 backdrop-blur-sm transition-opacity duration-300"
          onClick={() => setIsOpen(false)}
          aria-hidden="true"
        />
      )}

      {/* Floating Button Container */}
      <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 md:bottom-8 md:right-8 z-50 flex flex-col items-end gap-3">
        {/* Action Buttons */}
        {isOpen && (
          <div className="flex flex-col gap-2 mb-2 animate-fade-in-up">
            {actions.map((action, index) => {
              const Icon = action.icon;
              return (
                <a
                  key={index}
                  href={action.href}
                  target={action.href.startsWith('http') ? '_blank' : undefined}
                  rel={action.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className={`flex items-center gap-3 px-4 py-3 ${action.color} text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105`}
                  style={{ animationDelay: `${index * 0.1}s` }}
                  aria-label={action.ariaLabel}
                >
                  <Icon size={20} className="flex-shrink-0" />
                  <span className="text-sm font-semibold whitespace-nowrap pr-1">{action.label}</span>
                </a>
              );
            })}
          </div>
        )}

        {/* Main Toggle Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`relative w-14 h-14 sm:w-16 sm:h-16 rounded-full shadow-xl transition-all duration-300 hover:scale-110 flex items-center justify-center ${
            isOpen
              ? 'bg-gray-700 hover:bg-gray-800'
              : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700'
          }`}
          aria-label={isOpen ? 'Close contact options' : 'Open contact options'}
          aria-expanded={isOpen}
        >
          {!isOpen && showPulse && (
            <span className="absolute inset-0 rounded-full bg-cyan-500 animate-ping opacity-30" />
          )}
          {isOpen ? (
            <X size={24} className="text-white" />
          ) : (
            <MessageCircle size={24} className="text-white" />
          )}
        </button>
      </div>
    </>
  );
}
