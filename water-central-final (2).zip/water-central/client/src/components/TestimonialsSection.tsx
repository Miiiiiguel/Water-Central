import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const testimonials = [
    {
      name: 'María González',
      role: 'Madre de Familia',
      text: 'Desde que instalamos el sistema Water Central, mi familia ha notado una diferencia increíble en la salud. El agua tiene un sabor más fresco y mis hijos están más saludables.',
      rating: 5,
    },
    {
      name: 'Carlos Rodríguez',
      role: 'Empresario',
      text: 'Excelente servicio y producto. El equipo fue muy profesional en la instalación y el seguimiento ha sido impecable. Recomiendo Water Central sin dudarlo.',
      rating: 5,
    },
    {
      name: 'Ana Martínez',
      role: 'Profesional de Salud',
      text: 'Como profesional de la salud, sé la importancia del agua pura. Water Central ofrece exactamente eso. Calidad garantizada y atención al cliente excepcional.',
      rating: 5,
    },
    {
      name: 'Jorge López',
      role: 'Padre de Familia',
      text: 'Mi esposa estaba preocupada por la calidad del agua para nuestros bebés. Water Central resolvió todas nuestras dudas. Estamos muy satisfechos.',
      rating: 5,
    },
  ];

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const isActive = (index: number) => index === currentIndex;

  return (
    <section id="testimonios" className="py-20 md:py-32 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container relative z-10">
        {/* Section Header */}
        <div className={`text-center mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="text-5xl md:text-6xl font-bold text-primary mb-4">
            Lo Que Dicen
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-600">
              Nuestros Clientes
            </span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Descubre cómo Water Central ha transformado la salud y calidad de vida de miles de familias.
          </p>
        </div>

        {/* Testimonials Carousel */}
        <div className="max-w-4xl mx-auto">
          {/* Current Testimonial */}
          <div className={`bg-gradient-to-br from-white to-gray-50 rounded-2xl border border-gray-200 p-8 md:p-12 mb-8 shadow-premium-lg transition-all duration-500 hover:shadow-premium-lg ${
            isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
          }`}>
            {/* Stars */}
            <div className="flex gap-1 mb-4">
              {Array.from({ length: testimonials[currentIndex].rating }).map((_, i) => (
                <Star key={i} size={20} className="fill-yellow-400 text-yellow-400 animate-pulse" style={{ animationDelay: `${i * 100}ms` }} />
              ))}
            </div>

            {/* Quote */}
            <p className="text-lg md:text-xl text-foreground mb-6 leading-relaxed italic font-medium">
              "{testimonials[currentIndex].text}"
            </p>

            {/* Author */}
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-lg shadow-glow">
                {testimonials[currentIndex].name.charAt(0)}
              </div>
              <div>
                <p className="font-bold text-primary">{testimonials[currentIndex].name}</p>
                <p className="text-muted-foreground text-sm">{testimonials[currentIndex].role}</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <Button
              onClick={prev}
              variant="outline"
              size="icon"
              className="rounded-full border-2 border-accent text-accent hover:bg-gradient-to-r hover:from-cyan-500 hover:to-blue-600 hover:text-white hover:border-0 transition-all duration-300 hover:scale-110 shadow-glow"
            >
              <ChevronLeft size={20} />
            </Button>

            {/* Indicators */}
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`h-3 rounded-full transition-all duration-300 ${
                    isActive(index)
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 w-8 shadow-glow'
                      : 'bg-border hover:bg-muted-foreground w-3'
                  }`}
                />
              ))}
            </div>

            <Button
              onClick={next}
              variant="outline"
              size="icon"
              className="rounded-full border-2 border-accent text-accent hover:bg-gradient-to-r hover:from-cyan-500 hover:to-blue-600 hover:text-white hover:border-0 transition-all duration-300 hover:scale-110 shadow-glow"
            >
              <ChevronRight size={20} />
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className={`grid grid-cols-3 gap-4 md:gap-8 mt-16 pt-16 border-t border-gray-200 transition-all duration-700 delay-300 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          {[
            { value: '250K+', label: 'Familias Satisfechas' },
            { value: '4.9/5', label: 'Calificación Promedio' },
            { value: '98%', label: 'Recomendación' },
          ].map((stat, index) => (
            <div key={index} className="text-center group hover-lift">
              <div className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-600 mb-2 group-hover:scale-110 transition-transform">
                {stat.value}
              </div>
              <p className="text-muted-foreground text-sm group-hover:text-foreground transition-colors">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
