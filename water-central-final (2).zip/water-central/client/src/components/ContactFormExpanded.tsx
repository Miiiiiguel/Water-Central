import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Mail, Phone, MapPin, Send, CheckCircle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function ContactFormExpanded() {
  const { language } = useLanguage();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    city: '',
    propertyType: 'house',
    familySize: '4-5',
    waterConcerns: [] as string[],
    message: '',
    subscribe: true,
  });
  const [submitted, setSubmitted] = useState(false);
  const [step, setStep] = useState(1);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData({
        ...formData,
        [name]: checked,
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleCheckbox = (concern: string) => {
    setFormData({
      ...formData,
      waterConcerns: formData.waterConcerns.includes(concern)
        ? formData.waterConcerns.filter((c) => c !== concern)
        : [...formData.waterConcerns, concern],
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    setSubmitted(true);
    setTimeout(() => {
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        city: '',
        propertyType: 'house',
        familySize: '4-5',
        waterConcerns: [] as string[],
        message: '',
        subscribe: true,
      });
      setStep(1);
      setSubmitted(false);
    }, 3000);
  };

  const waterConcerns = [
    { id: 'chlorine', label: language === 'es' ? 'Cloro' : 'Chlorine' },
    { id: 'hardness', label: language === 'es' ? 'Dureza del Agua' : 'Water Hardness' },
    { id: 'taste', label: language === 'es' ? 'Mal Sabor/Olor' : 'Bad Taste/Smell' },
    { id: 'sediment', label: language === 'es' ? 'Sedimento' : 'Sediment' },
    { id: 'bacteria', label: language === 'es' ? 'Bacterias' : 'Bacteria' },
    { id: 'minerals', label: language === 'es' ? 'Minerales Pesados' : 'Heavy Minerals' },
  ];

  const contactInfo = [
    {
      icon: Phone,
      label: language === 'es' ? 'Teléfono' : 'Phone',
      value: '+1 (800) 748-4189',
      href: 'tel:+1800748189',
    },
    {
      icon: Mail,
      label: language === 'es' ? 'Email' : 'Email',
      value: 'info@watercentral.com',
      href: 'mailto:info@watercentral.com',
    },
  ];

  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="animate-fade-in-left">
            <h2 className="font-display text-5xl md:text-6xl font-bold text-primary mb-4">
              {language === 'es' ? 'Solicita Tu Prueba Gratuita' : 'Request Your Free Trial'}
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              {language === 'es'
                ? 'Completa el formulario y nuestro equipo te contactará en 24 horas con un análisis completo de tu agua.'
                : 'Complete the form and our team will contact you within 24 hours with a complete analysis of your water.'}
            </p>

            {/* Contact Methods */}
            <div className="space-y-6 mb-12">
              {contactInfo.map((info, index) => {
                const Icon = info.icon;
                return (
                  <a
                    key={index}
                    href={info.href}
                    className="flex items-start gap-4 p-4 rounded-lg hover:bg-gray-50 transition-all duration-300 group"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center flex-shrink-0 shadow-glow group-hover:shadow-glow-lg transition-all">
                      <Icon className="text-white" size={24} />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{info.label}</p>
                      <p className="text-muted-foreground group-hover:text-accent transition-colors">{info.value}</p>
                    </div>
                  </a>
                );
              })}
            </div>

            {/* Trust Badges */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-cyan-500" />
                <span className="text-sm font-medium text-foreground">
                  {language === 'es' ? '100% Confidencial' : '100% Confidential'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-cyan-500" />
                <span className="text-sm font-medium text-foreground">
                  {language === 'es' ? 'Sin Obligación' : 'No Obligation'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-cyan-500" />
                <span className="text-sm font-medium text-foreground">
                  {language === 'es' ? 'Respuesta en 24 Horas' : 'Response in 24 Hours'}
                </span>
              </div>
            </div>
          </div>

          {/* Contact Form - Multi-Step */}
          <div className="animate-fade-in-right">
            <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-gray-200 p-8 shadow-premium-lg">
              {/* Progress Indicator */}
              <div className="flex gap-2 mb-8">
                {[1, 2, 3].map((s) => (
                  <div
                    key={s}
                    className={`h-2 flex-1 rounded-full transition-all duration-300 ${
                      s <= step
                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600'
                        : 'bg-gray-200'
                    }`}
                  />
                ))}
              </div>

              <div className="space-y-6">
                {/* Step 1: Personal Info */}
                {step === 1 && (
                  <>
                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">
                        {language === 'es' ? 'Nombre' : 'First Name'} *
                      </label>
                      <input
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-300"
                        placeholder={language === 'es' ? 'Tu nombre' : 'Your first name'}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">
                        {language === 'es' ? 'Apellido' : 'Last Name'} *
                      </label>
                      <input
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-300"
                        placeholder={language === 'es' ? 'Tu apellido' : 'Your last name'}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">
                        Email *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-300"
                        placeholder={language === 'es' ? 'tu@email.com' : 'your@email.com'}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">
                        {language === 'es' ? 'Teléfono' : 'Phone'} *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-300"
                        placeholder="+1 (800) 000-0000"
                      />
                    </div>
                  </>
                )}

                {/* Step 2: Property Info */}
                {step === 2 && (
                  <>
                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">
                        {language === 'es' ? 'Ciudad' : 'City'} *
                      </label>
                      <input
                        type="text"
                        name="city"
                        value={formData.city}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-300"
                        placeholder={language === 'es' ? 'Tu ciudad' : 'Your city'}
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">
                        {language === 'es' ? 'Tipo de Propiedad' : 'Property Type'} *
                      </label>
                      <select
                        name="propertyType"
                        value={formData.propertyType}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-300"
                      >
                        <option value="house">{language === 'es' ? 'Casa' : 'House'}</option>
                        <option value="apartment">{language === 'es' ? 'Apartamento' : 'Apartment'}</option>
                        <option value="condo">{language === 'es' ? 'Condominio' : 'Condo'}</option>
                        <option value="commercial">{language === 'es' ? 'Comercial' : 'Commercial'}</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">
                        {language === 'es' ? 'Tamaño de la Familia' : 'Family Size'} *
                      </label>
                      <select
                        name="familySize"
                        value={formData.familySize}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-300"
                      >
                        <option value="1-2">{language === 'es' ? '1-2 personas' : '1-2 people'}</option>
                        <option value="3-4">{language === 'es' ? '3-4 personas' : '3-4 people'}</option>
                        <option value="4-5">{language === 'es' ? '4-5 personas' : '4-5 people'}</option>
                        <option value="6+">{language === 'es' ? '6+ personas' : '6+ people'}</option>
                      </select>
                    </div>
                  </>
                )}

                {/* Step 3: Water Concerns */}
                {step === 3 && (
                  <>
                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-4">
                        {language === 'es' ? '¿Cuáles son tus preocupaciones sobre el agua?' : 'What are your water concerns?'} *
                      </label>
                      <div className="grid grid-cols-2 gap-3">
                        {waterConcerns.map((concern) => (
                          <label
                            key={concern.id}
                            className="flex items-center gap-2 p-3 border border-gray-300 rounded-lg hover:border-cyan-500 hover:bg-cyan-50 cursor-pointer transition-all duration-300"
                          >
                            <input
                              type="checkbox"
                              checked={formData.waterConcerns.includes(concern.id)}
                              onChange={() => handleCheckbox(concern.id)}
                              className="w-4 h-4 rounded border-gray-300 text-cyan-600 focus:ring-cyan-500"
                            />
                            <span className="text-sm font-medium text-foreground">{concern.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-foreground mb-2">
                        {language === 'es' ? 'Mensaje Adicional' : 'Additional Message'}
                      </label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        rows={4}
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all duration-300 resize-none"
                        placeholder={language === 'es' ? 'Cuéntanos más...' : 'Tell us more...'}
                      ></textarea>
                    </div>

                    <label className="flex items-center gap-2 p-3 border border-gray-300 rounded-lg hover:border-cyan-500 hover:bg-cyan-50 cursor-pointer transition-all duration-300">
                      <input
                        type="checkbox"
                        name="subscribe"
                        checked={formData.subscribe}
                        onChange={handleChange}
                        className="w-4 h-4 rounded border-gray-300 text-cyan-600 focus:ring-cyan-500"
                      />
                      <span className="text-sm font-medium text-foreground">
                        {language === 'es'
                          ? 'Sí, deseo recibir consejos sobre agua pura y ofertas especiales'
                          : 'Yes, I want to receive tips about pure water and special offers'}
                      </span>
                    </label>
                  </>
                )}

                {/* Navigation Buttons */}
                <div className="flex gap-3 pt-4">
                  {step > 1 && (
                    <Button
                      type="button"
                      onClick={() => setStep(step - 1)}
                      variant="outline"
                      className="flex-1"
                    >
                      {language === 'es' ? 'Atrás' : 'Back'}
                    </Button>
                  )}
                  {step < 3 ? (
                    <Button
                      type="button"
                      onClick={() => setStep(step + 1)}
                      className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white border-0"
                    >
                      {language === 'es' ? 'Siguiente' : 'Next'}
                    </Button>
                  ) : (
                    <Button
                      type="submit"
                      className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white border-0 shadow-glow-lg hover:shadow-glow-lg transition-all duration-300 hover:scale-105 flex items-center justify-center gap-2"
                    >
                      <Send size={18} />
                      {language === 'es' ? 'Enviar' : 'Submit'}
                    </Button>
                  )}
                </div>

                {/* Success Message */}
                {submitted && (
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-green-700 text-center animate-fade-in-up flex items-center justify-center gap-2">
                    <CheckCircle size={20} />
                    {language === 'es'
                      ? '¡Formulario enviado! Te contactaremos en 24 horas.'
                      : 'Form submitted! We will contact you within 24 hours.'}
                  </div>
                )}
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
