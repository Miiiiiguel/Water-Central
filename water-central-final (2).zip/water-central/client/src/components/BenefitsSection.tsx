import { Heart, Leaf, Shield } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function BenefitsSection() {
  const [isVisible, setIsVisible] = useState(false);
  const { t, language } = useLanguage();

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const benefits = [
    {
      icon: Heart,
      title: t('benefits.benefit1'),
      description: t('benefits.benefit1_desc'),
      stats: t('benefits.benefit1_stats'),
      color: 'from-red-500 to-pink-500',
    },
    {
      icon: Leaf,
      title: t('benefits.benefit2'),
      description: t('benefits.benefit2_desc'),
      stats: t('benefits.benefit2_stats'),
      color: 'from-green-500 to-emerald-500',
    },
    {
      icon: Shield,
      title: t('benefits.benefit3'),
      description: t('benefits.benefit3_desc'),
      stats: t('benefits.benefit3_stats'),
      color: 'from-blue-500 to-cyan-500',
    },
  ];

  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 right-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container relative z-10">
        {/* Section Header */}
        <div className={`text-center mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="text-5xl md:text-6xl font-bold text-primary mb-4">
            {t('benefits.title')}
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-600">
              {t('benefits.subtitle')}
            </span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t('services.description')}
          </p>
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={index}
                className={`relative group transition-all duration-700 transform ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                {/* Gradient Background on Hover */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${benefit.color} rounded-xl opacity-0 group-hover:opacity-10 transition-opacity duration-300 blur-lg`}
                ></div>

                {/* Card */}
                <div className="relative bg-white rounded-xl p-8 border border-gray-200 hover:border-gray-300 hover:shadow-premium-lg transition-all duration-300">
                  {/* Icon */}
                  <div className={`w-16 h-16 bg-gradient-to-br ${benefit.color} rounded-lg flex items-center justify-center mb-6 shadow-glow group-hover:shadow-glow-lg transition-all duration-300 group-hover:scale-110`}>
                    <Icon className="text-white" size={32} />
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold text-primary mb-3 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-cyan-500 group-hover:to-blue-600 transition-all">
                    {benefit.title}
                  </h3>
                  <p className="text-muted-foreground mb-6 leading-relaxed">{benefit.description}</p>

                  {/* Stats */}
                  <div className="pt-6 border-t border-gray-200 group-hover:border-gray-300 transition-colors">
                    <p className="text-sm font-semibold text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-600">
                      {benefit.stats}
                    </p>
                  </div>

                  {/* Animated Border */}
                  <div className="absolute inset-0 rounded-xl border-2 border-transparent bg-gradient-to-r from-cyan-500 to-blue-600 opacity-0 group-hover:opacity-20 transition-opacity duration-300 pointer-events-none"></div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Comparison Section */}
        <div className={`bg-gradient-to-r from-slate-50 to-gray-50 rounded-2xl border border-gray-200 p-8 md:p-12 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h3 className="text-3xl font-bold text-primary mb-8 text-center">
            {t('benefits.comparison')}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Before */}
            <div className="text-center group">
              <div className="mb-4 relative overflow-hidden rounded-lg shadow-premium">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663507101400/M3vGFBvXTzeHHq6Z95nygi/water-benefits-visual-CssWjdaSwkFCMM2d22dBrx.webp"
                  alt={language === 'es' ? 'Agua contaminada' : 'Contaminated water'}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h4 className="text-lg font-bold text-foreground mb-2">{t('benefits.before')}</h4>
              <ul className="text-muted-foreground text-sm space-y-2">
                <li className="flex items-center justify-center gap-2">
                  <span className="text-red-500 font-bold">✕</span> {language === 'es' ? 'Cloro y químicos' : 'Chlorine & chemicals'}
                </li>
                <li className="flex items-center justify-center gap-2">
                  <span className="text-red-500 font-bold">✕</span> {language === 'es' ? 'Metales pesados' : 'Heavy metals'}
                </li>
                <li className="flex items-center justify-center gap-2">
                  <span className="text-red-500 font-bold">✕</span> {language === 'es' ? 'Bacterias y virus' : 'Bacteria & viruses'}
                </li>
                <li className="flex items-center justify-center gap-2">
                  <span className="text-red-500 font-bold">✕</span> {language === 'es' ? 'Sabor desagradable' : 'Bad taste & odor'}
                </li>
              </ul>
            </div>

            {/* After */}
            <div className="text-center group">
              <div className="mb-4 relative overflow-hidden rounded-lg shadow-glow-lg">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663507101400/M3vGFBvXTzeHHq6Z95nygi/water-drop-tech-3QFPTBW2giS3B8xYRCKd7.webp"
                  alt={language === 'es' ? 'Agua pura' : 'Pure water'}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h4 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-600 mb-2">
                {t('benefits.after')}
              </h4>
              <ul className="text-muted-foreground text-sm space-y-2">
                <li className="flex items-center justify-center gap-2">
                  <span className="text-green-500 font-bold">✓</span> {language === 'es' ? '100% pura y cristalina' : '100% pure & crystal clear'}
                </li>
                <li className="flex items-center justify-center gap-2">
                  <span className="text-green-500 font-bold">✓</span> {language === 'es' ? 'Libre de contaminantes' : 'Free from contaminants'}
                </li>
                <li className="flex items-center justify-center gap-2">
                  <span className="text-green-500 font-bold">✓</span> {language === 'es' ? 'Rica en minerales esenciales' : 'Rich in essential minerals'}
                </li>
                <li className="flex items-center justify-center gap-2">
                  <span className="text-green-500 font-bold">✓</span> {language === 'es' ? 'Sabor fresco y natural' : 'Fresh & natural taste'}
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
