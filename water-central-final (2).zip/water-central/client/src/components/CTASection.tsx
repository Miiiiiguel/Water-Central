import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Sparkles } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function CTASection() {
  const { language } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setIsVisible(true); },
      { threshold: 0.1 }
    );
    const el = document.getElementById('cta-section');
    if (el) observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const features = language === 'es'
    ? [
        { title: 'Prueba Gratuita', desc: 'Sin costo ni obligación' },
        { title: 'Análisis Completo', desc: 'Identificamos todos los contaminantes' },
        { title: 'Solución Personalizada', desc: 'Recomendaciones adaptadas a ti' },
      ]
    : [
        { title: 'Free Water Test', desc: 'No cost, no obligation' },
        { title: 'Full Analysis', desc: 'We identify all contaminants' },
        { title: 'Custom Solution', desc: 'Recommendations tailored to you' },
      ];

  return (
    <section id="cta-section" className="py-20 md:py-32 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-primary via-blue-700 to-primary"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Content */}
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Badge */}
          <div
            className={`inline-flex items-center gap-2 px-4 py-2 bg-white/10 border border-white/30 rounded-full mb-6 backdrop-blur-lg transition-all duration-700 ${
              isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
            }`}
          >
            <Sparkles size={16} className="text-cyan-300 animate-pulse" />
            <span className="text-white text-sm font-semibold">
              {language === 'es' ? 'Oferta Especial' : 'Special Offer'}
            </span>
          </div>

          {/* Headline */}
          <h2
            className={`text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            {language === 'es' ? (
              <>
                ¿Listo para Transformar
                <span className="block text-cyan-300">tu Agua?</span>
              </>
            ) : (
              <>
                Ready to Transform
                <span className="block text-cyan-300">Your Water?</span>
              </>
            )}
          </h2>

          {/* Subheadline */}
          <p
            className={`text-base sm:text-lg md:text-xl text-cyan-100 mb-8 leading-relaxed transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            {language === 'es'
              ? 'Solicita una prueba de agua gratuita y descubre qué contaminantes hay en tu hogar. Sin compromiso, sin costo.'
              : 'Request a free water quality test and discover what contaminants are in your home. No commitment, no cost.'}
          </p>

          {/* Features */}
          <div
            className={`grid grid-cols-1 md:grid-cols-3 gap-4 mb-12 text-left transition-all duration-700 delay-300 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            {features.map((feature, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-4 rounded-lg bg-white/5 backdrop-blur-lg border border-white/10 hover:bg-white/10 transition-all duration-300 group hover-lift"
              >
                <CheckCircle size={24} className="text-cyan-300 flex-shrink-0 mt-1 group-hover:scale-110 transition-transform" />
                <div>
                  <h4 className="font-semibold text-white mb-1 group-hover:text-cyan-200 transition-colors">
                    {feature.title}
                  </h4>
                  <p className="text-cyan-100 text-sm group-hover:text-cyan-50 transition-colors">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* CTA Button */}
          <div
            className={`transition-all duration-700 delay-400 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <Button
              className="bg-gradient-to-r from-cyan-400 to-cyan-500 hover:from-cyan-500 hover:to-cyan-600 text-primary px-8 sm:px-10 py-6 sm:py-7 text-base sm:text-lg font-bold flex items-center gap-2 mx-auto border-0 shadow-glow-lg hover:shadow-glow-lg transition-all duration-300 hover:scale-105 group"
              onClick={() => {
                const el = document.getElementById('contacto');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              {language === 'es' ? 'Solicitar Prueba Gratuita' : 'Get Your Free Water Test'}
              <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />
            </Button>
          </div>

          {/* Trust Indicators */}
          <p
            className={`text-cyan-100 text-sm mt-8 transition-all duration-700 delay-500 ${
              isVisible ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <span className="inline-flex items-center gap-2">
              <span className="w-2 h-2 bg-cyan-300 rounded-full animate-pulse"></span>
              {language === 'es' ? 'Confianza de 250K+ familias' : 'Trusted by 250K+ families'}
            </span>
            <span className="mx-3">•</span>
            <span>{language === 'es' ? 'Certificado NSF/WQA' : 'Certified NSF/WQA'}</span>
            <span className="mx-3">•</span>
            <span>{language === 'es' ? 'Soporte 24/7' : '24/7 Support'}</span>
          </p>
        </div>
      </div>
    </section>
  );
}
