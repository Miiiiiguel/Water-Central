import { Mail, Phone, MapPin } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Footer() {
  const { language } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);
  const currentYear = new Date().getFullYear();

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const services = language === 'es'
    ? [
        { label: 'Sistema Integral 10 Etapas', href: '#servicios' },
        { label: 'Ósmosis Inversa', href: '#servicios' },
        { label: 'Suavizadores de Agua', href: '#servicios' },
        { label: 'Mantenimiento', href: '#servicios' },
      ]
    : [
        { label: '10-Stage Whole Home System', href: '#servicios' },
        { label: 'Reverse Osmosis', href: '#servicios' },
        { label: 'Water Softeners', href: '#servicios' },
        { label: 'Maintenance & Service', href: '#servicios' },
      ];

  const company = language === 'es'
    ? [
        { label: 'Sobre Nosotros', href: '#' },
        { label: 'Blog', href: '#' },
        { label: 'Carreras', href: '#' },
        { label: 'Contacto', href: '#contacto' },
      ]
    : [
        { label: 'About Us', href: '#' },
        { label: 'Blog', href: '#' },
        { label: 'Careers', href: '#' },
        { label: 'Contact', href: '#contacto' },
      ];

  const legal = language === 'es'
    ? [
        { label: 'Política de Privacidad', href: '#' },
        { label: 'Términos de Servicio', href: '#' },
        { label: 'Política de Cookies', href: '#' },
      ]
    : [
        { label: 'Privacy Policy', href: '#' },
        { label: 'Terms of Service', href: '#' },
        { label: 'Cookie Policy', href: '#' },
      ];

  return (
    <footer className="bg-gradient-to-b from-slate-900 to-slate-950 text-gray-300 py-16 md:py-20 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container relative z-10">
        {/* Main Footer */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="flex items-center gap-2 mb-4 group hover-scale">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center shadow-glow group-hover:shadow-glow-lg transition-all">
                <span className="text-white font-bold text-lg">W</span>
              </div>
              <span className="font-bold text-white text-lg">Water Central</span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed">
              {language === 'es'
                ? 'Pureza y salud en cada gota. Transformando la calidad de vida de familias con sistemas de filtración de agua avanzados.'
                : 'Purity and health in every drop. Transforming families\' quality of life with advanced water filtration systems.'}
            </p>
          </div>

          {/* Services */}
          <div className={`transition-all duration-700 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h4 className="font-semibold text-white mb-4">
              {language === 'es' ? 'Servicios' : 'Services'}
            </h4>
            <ul className="space-y-2 text-sm">
              {services.map((item) => (
                <li key={item.label}>
                  <a href={item.href} className="hover:text-cyan-400 transition-colors hover:translate-x-1 inline-block transition-transform">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div className={`transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h4 className="font-semibold text-white mb-4">
              {language === 'es' ? 'Empresa' : 'Company'}
            </h4>
            <ul className="space-y-2 text-sm">
              {company.map((item) => (
                <li key={item.label}>
                  <a href={item.href} className="hover:text-cyan-400 transition-colors hover:translate-x-1 inline-block transition-transform">
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className={`transition-all duration-700 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h4 className="font-semibold text-white mb-4">
              {language === 'es' ? 'Contacto' : 'Contact'}
            </h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2 group">
                <Phone size={16} className="text-cyan-400 flex-shrink-0 group-hover:scale-110 transition-transform" />
                <a href="tel:+18007484189" className="hover:text-cyan-400 transition-colors">
                  +1 (800) 748-4189
                </a>
              </li>
              <li className="flex items-center gap-2 group">
                <Mail size={16} className="text-cyan-400 flex-shrink-0 group-hover:scale-110 transition-transform" />
                <a href="mailto:info@watercentral.com" className="hover:text-cyan-400 transition-colors">
                  info@watercentral.com
                </a>
              </li>
              <li className="flex items-start gap-2 group">
                <MapPin size={16} className="text-cyan-400 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform" />
                <span className="group-hover:text-cyan-400 transition-colors">
                  {language === 'es'
                    ? 'Texas, Florida & Puerto Rico'
                    : 'Texas, Florida & Puerto Rico'}
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-slate-700 my-8"></div>

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center text-sm text-gray-400 mb-8 gap-4">
          <p>&copy; {currentYear} Water Central. {language === 'es' ? 'Todos los derechos reservados.' : 'All rights reserved.'}</p>
          <div className="flex flex-wrap justify-center gap-4 md:gap-6">
            {legal.map((item) => (
              <a key={item.label} href={item.href} className="hover:text-cyan-400 transition-colors">
                {item.label}
              </a>
            ))}
          </div>
        </div>

        {/* Social Links */}
        <div className="flex justify-center gap-4">
          {['Facebook', 'Instagram', 'LinkedIn', 'Twitter'].map((social, index) => (
            <a
              key={social}
              href="#"
              aria-label={`Follow us on ${social}`}
              className={`w-10 h-10 bg-slate-800 hover:bg-gradient-to-r hover:from-cyan-500 hover:to-blue-600 rounded-full flex items-center justify-center hover:text-white text-gray-400 text-sm font-semibold transition-all duration-300 hover:scale-110 shadow-glow hover:shadow-glow-lg ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 50}ms` }}
            >
              {social.charAt(0)}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
}
