import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Eye, Download, X, FileText, Sparkles } from 'lucide-react';
import { useEffect, useState, useCallback } from 'react';

const products = [
  {
    id: 1,
    image: '/images/products/tank-stainless-10-stages.jpeg',
    titleEn: 'Stainless Steel 10-Stage Whole House Water System',
    titleEs: 'Sistema de Agua 10 Etapas Acero Inoxidable para Toda la Casa',
    descEn: 'Our flagship whole-home water purification system with 10 stages of advanced filtration. Removes lead, chlorine, heavy metals, and contaminants while adding beneficial minerals.',
    descEs: 'Nuestro sistema insignia de purificación de agua para toda la casa con 10 etapas de filtración avanzada. Elimina plomo, cloro, metales pesados y contaminantes mientras añade minerales beneficiosos.',
    features: {
      en: ['10-Stage Filtration', 'Whole Home Coverage', 'Stainless Steel Build', '#1 Valve in the World'],
      es: ['Filtración 10 Etapas', 'Cobertura Toda la Casa', 'Acero Inoxidable', 'Válvula #1 del Mundo'],
    },
    badge: { en: 'Best Seller', es: 'Más Vendido' },
  },
  {
    id: 2,
    image: '/images/products/tank-black-10-stages.webp',
    titleEn: '10-Stage Premium Black Whole House Water Softener',
    titleEs: 'Suavizador de Agua 10 Etapas Premium Negro para Toda la Casa',
    descEn: 'Sleek black design with the same powerful 10-stage purification technology. Softens water, removes contaminants, and delivers pure alkaline water throughout your entire home.',
    descEs: 'Diseño negro elegante con la misma potente tecnología de purificación de 10 etapas. Suaviza el agua, elimina contaminantes y entrega agua alcalina pura en toda tu casa.',
    features: {
      en: ['10-Stage Purification', 'Water Softening', 'Alkaline Output', 'Premium Design'],
      es: ['Purificación 10 Etapas', 'Suavizado de Agua', 'Salida Alcalina', 'Diseño Premium'],
    },
    badge: { en: 'Premium', es: 'Premium' },
  },
];

const brochurePages = [
  '/brochure/brochure-page-1.jpg',
  '/brochure/brochure-page-2.jpg',
  '/brochure/brochure-page-3.jpg',
  '/brochure/brochure-page-4.jpg',
  '/brochure/brochure-page-5.jpg',
];

export default function ProductsSection() {
  const { language } = useLanguage();
  const [currentProduct, setCurrentProduct] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [showBrochure, setShowBrochure] = useState(false);
  const [brochurePage, setBrochurePage] = useState(0);
  const [imageLoaded, setImageLoaded] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setIsVisible(true); },
      { threshold: 0.1 }
    );
    const el = document.getElementById('productos') || document.querySelector('section');
    if (el) observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const nextProduct = useCallback(() => {
    setImageLoaded(false);
    setCurrentProduct((prev) => (prev + 1) % products.length);
  }, []);

  const prevProduct = useCallback(() => {
    setImageLoaded(false);
    setCurrentProduct((prev) => (prev - 1 + products.length) % products.length);
  }, []);

  const product = products[currentProduct];

  return (
    <>
      <section className="py-20 md:py-32 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-float"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }}></div>
        </div>

        <div className="container relative z-10">
          {/* Section Header */}
          <div className={`text-center mb-12 md:mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-cyan-500/10 border border-cyan-500/30 rounded-full mb-6">
              <Sparkles size={16} className="text-cyan-600" />
              <span className="text-cyan-700 font-semibold text-sm">
                {language === 'es' ? 'Productos Destacados' : 'Featured Products'}
              </span>
            </div>
            <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-primary mb-4">
              {language === 'es' ? 'Elige la Mejor' : 'Choose the Best'}
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-600">
                {language === 'es' ? 'Filtración de Agua' : 'Water Filtration'}
              </span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {language === 'es'
                ? 'Sistemas revolucionarios de 10 etapas con el doble de capacidad que otros sistemas residenciales.'
                : 'Revolutionary 10-stage systems with double the capacity of other residential water systems.'}
            </p>
          </div>

          {/* Product Carousel */}
          <div className={`transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center max-w-6xl mx-auto">
              {/* Product Image */}
              <div className="relative group order-1">
                <div className="relative bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 md:p-10 border border-gray-200 shadow-premium-lg overflow-hidden">
                  {/* Badge */}
                  <div className="absolute top-4 left-4 z-10 px-3 py-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold rounded-full shadow-glow">
                    {language === 'es' ? product.badge.es : product.badge.en}
                  </div>

                  {/* Image */}
                  <div className="relative w-full flex justify-center items-center" style={{ minHeight: '350px' }}>
                    <img
                      src={product.image}
                      alt={language === 'es' ? product.titleEs : product.titleEn}
                      className={`max-h-[400px] md:max-h-[500px] w-auto object-contain transition-all duration-700 group-hover:scale-105 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
                      onLoad={() => setImageLoaded(true)}
                      loading="lazy"
                    />
                    {!imageLoaded && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
                      </div>
                    )}
                  </div>

                  {/* Navigation Arrows */}
                  <button
                    onClick={prevProduct}
                    className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 z-10 bg-white/90 hover:bg-white text-primary p-2 md:p-3 rounded-full shadow-lg hover:shadow-glow-lg transition-all duration-300 hover:scale-110"
                    aria-label="Previous product"
                  >
                    <ChevronLeft size={20} />
                  </button>
                  <button
                    onClick={nextProduct}
                    className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 z-10 bg-white/90 hover:bg-white text-primary p-2 md:p-3 rounded-full shadow-lg hover:shadow-glow-lg transition-all duration-300 hover:scale-110"
                    aria-label="Next product"
                  >
                    <ChevronRight size={20} />
                  </button>

                  {/* Dots */}
                  <div className="flex justify-center gap-2 mt-6">
                    {products.map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => { setImageLoaded(false); setCurrentProduct(idx); }}
                        className={`h-2.5 rounded-full transition-all duration-300 ${
                          idx === currentProduct
                            ? 'bg-gradient-to-r from-cyan-500 to-blue-600 w-8'
                            : 'bg-gray-300 w-2.5 hover:bg-gray-400'
                        }`}
                        aria-label={`Go to product ${idx + 1}`}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Product Info */}
              <div className="order-2 space-y-6">
                <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold text-primary leading-tight">
                  {language === 'es' ? product.titleEs : product.titleEn}
                </h3>

                <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
                  {language === 'es' ? product.descEs : product.descEn}
                </p>

                {/* Features */}
                <div className="grid grid-cols-2 gap-3">
                  {(language === 'es' ? product.features.es : product.features.en).map((feature, i) => (
                    <div key={i} className="flex items-center gap-2 p-3 bg-cyan-50 rounded-lg border border-cyan-100">
                      <div className="w-2 h-2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 flex-shrink-0"></div>
                      <span className="text-sm font-medium text-foreground">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* 10 Stage Info */}
                <div className="bg-gradient-to-r from-primary to-blue-700 rounded-xl p-5 text-white">
                  <h4 className="font-bold text-lg mb-2">
                    {language === 'es' ? '10 Etapas de Purificación' : '10-Stage Purification Process'}
                  </h4>
                  <p className="text-cyan-100 text-sm leading-relaxed">
                    {language === 'es'
                      ? 'Resina suavizadora, Carbón catalítico, KDF Media, PH Alcalino, Grava, Rayos Infrarrojos, Reducción de Oxidación, Turmalina, Esferas Cerámicas Maifan, Minerales.'
                      : 'Softening Resin, Catalytic Carbon, KDF Media, PH Alkaline Media, Gravel, Far-Infra Red Rays, Oxidation Reduction, Tourmaline, Maifan Ceramic Balls, Minerals.'}
                  </p>
                </div>

                {/* CTA Buttons */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button
                    className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white border-0 px-6 py-5 text-base font-semibold shadow-glow hover:shadow-glow-lg transition-all duration-300 hover:scale-105"
                    onClick={() => {
                      const el = document.getElementById('contacto');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                  >
                    {language === 'es' ? 'Solicitar Prueba Gratuita' : 'Get a Free Water Test'}
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 border-2 border-cyan-500 text-cyan-700 hover:bg-cyan-50 px-6 py-5 text-base font-semibold transition-all duration-300 flex items-center justify-center gap-2"
                    onClick={() => setShowBrochure(true)}
                  >
                    <Eye size={18} />
                    {language === 'es' ? 'Ver Folleto' : 'View Brochure'}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Brochure CTA Banner */}
          <div className={`mt-16 transition-all duration-700 delay-400 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="bg-gradient-to-r from-primary via-blue-700 to-primary rounded-2xl p-6 md:p-10 text-white relative overflow-hidden">
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-400 rounded-full blur-3xl"></div>
                <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-400 rounded-full blur-3xl"></div>
              </div>
              <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm border border-white/30 flex-shrink-0">
                    <FileText size={28} className="text-cyan-300" />
                  </div>
                  <div>
                    <h3 className="text-xl md:text-2xl font-bold">
                      {language === 'es'
                        ? 'Descarga Nuestro Folleto Completo'
                        : 'Download Our Complete Brochure'}
                    </h3>
                    <p className="text-cyan-100 text-sm md:text-base">
                      {language === 'es'
                        ? 'Conoce todos los detalles del proceso de purificación de 10 etapas'
                        : 'Learn all the details about our 10-stage purification process'}
                    </p>
                  </div>
                </div>
                <div className="flex gap-3 flex-shrink-0">
                  <Button
                    className="bg-white text-primary hover:bg-gray-100 border-0 px-6 py-5 font-bold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 flex items-center gap-2"
                    onClick={() => setShowBrochure(true)}
                  >
                    <Eye size={18} />
                    {language === 'es' ? 'Ver Folleto' : 'View Brochure'}
                  </Button>
                  <a
                    href="/brochure/water-central-brochure.pdf"
                    download
                    className="inline-flex items-center gap-2 px-6 py-3 bg-white/20 hover:bg-white/30 border border-white/40 rounded-lg text-white font-bold transition-all duration-300 hover:scale-105"
                  >
                    <Download size={18} />
                    PDF
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Brochure Modal */}
      {showBrochure && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in-up">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden shadow-2xl relative flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-primary to-blue-700 text-white flex-shrink-0">
              <div className="flex items-center gap-3">
                <FileText size={24} className="text-cyan-300" />
                <div>
                  <h3 className="font-bold text-lg">
                    {language === 'es' ? 'Folleto Water Central' : 'Water Central Brochure'}
                  </h3>
                  <p className="text-cyan-200 text-xs">
                    {language === 'es' ? `Página ${brochurePage + 1} de ${brochurePages.length}` : `Page ${brochurePage + 1} of ${brochurePages.length}`}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href="/brochure/water-central-brochure.pdf"
                  download
                  className="p-2 hover:bg-white/20 rounded-lg transition-colors"
                  title="Download PDF"
                >
                  <Download size={20} />
                </a>
                <button
                  onClick={() => { setShowBrochure(false); setBrochurePage(0); }}
                  className="p-2 hover:bg-white/20 rounded-lg transition-colors"
                  aria-label="Close brochure"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Brochure Image */}
            <div className="flex-1 overflow-auto bg-gray-100 flex items-center justify-center p-4">
              <img
                src={brochurePages[brochurePage]}
                alt={`Brochure page ${brochurePage + 1}`}
                className="max-w-full max-h-full object-contain rounded-lg shadow-lg"
                loading="lazy"
              />
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-between p-4 border-t border-gray-200 bg-white flex-shrink-0">
              <button
                onClick={() => setBrochurePage(Math.max(0, brochurePage - 1))}
                disabled={brochurePage === 0}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <ChevronLeft size={18} />
                {language === 'es' ? 'Anterior' : 'Previous'}
              </button>

              {/* Page Dots */}
              <div className="flex gap-2">
                {brochurePages.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setBrochurePage(idx)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      idx === brochurePage
                        ? 'bg-gradient-to-r from-cyan-500 to-blue-600 scale-125'
                        : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                    aria-label={`Go to page ${idx + 1}`}
                  />
                ))}
              </div>

              <button
                onClick={() => setBrochurePage(Math.min(brochurePages.length - 1, brochurePage + 1))}
                disabled={brochurePage === brochurePages.length - 1}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {language === 'es' ? 'Siguiente' : 'Next'}
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
