import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

type Language = 'es' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const translations = {
  es: {
    // Header
    'header.inicio': 'Inicio',
    'header.servicios': 'Servicios',
    'header.beneficios': 'Beneficios',
    'header.productos': 'Productos',
    'header.testimonios': 'Testimonios',
    'header.blog': 'Blog',
    'header.contacto': 'Contacto',
    'header.prueba': 'Prueba Gratuita',

    // Hero
    'hero.badge': '✓ Certificado NSF/WQA - Confianza Garantizada',
    'hero.title1': 'El agua que bebes',
    'hero.title2': 'podría estar enfermando',
    'hero.title3': 'a tu familia SIN que lo sepas',
    'hero.subtitle': 'Cada gota que tu familia bebe contiene metales pesados, cloro y bacterias. Water Central elimina el 100% de contaminantes. Descubre qué hay en tu agua ahora mismo con nuestra prueba gratuita.',
    'hero.cta1': 'Prueba Gratuita',
    'hero.cta2': 'Explorar Servicios',
    'hero.stat1': '250K+',
    'hero.stat1_label': 'Familias Protegidas',
    'hero.stat2': '10 Etapas',
    'hero.stat2_label': 'Filtración Avanzada',
    'hero.stat3': '100%',
    'hero.stat3_label': 'Purificación Garantizada',

    // Services
    'services.title': 'Soluciones Inteligentes',
    'services.subtitle': 'Para Cada Necesidad de tu Hogar',
    'services.description': 'No todos los hogares son iguales. Por eso ofrecemos 4 soluciones personalizadas que se adaptan a tu agua específica. Cada una diseñada para eliminar exactamente lo que contamina tu hogar.',
    'services.service1': 'Sistema Integral 10 Etapas',
    'services.service1_desc': 'Filtración completa para toda la casa. Elimina el 100% de plomo, cloro y metales pesados.',
    'services.service2': 'Ósmosis Inversa Alcalina',
    'services.service2_desc': 'Agua potable de máxima pureza con minerales esenciales. Perfecta para cocina y consumo directo.',
    'services.service3': 'Suavizadores de Agua',
    'services.service3_desc': 'Elimina el exceso de minerales y previene la acumulación de sarro en tuberías y electrodomésticos.',
    'services.service4': 'Mantenimiento y Soporte',
    'services.service4_desc': 'Servicio técnico completo, cambio de filtros y garantía de funcionamiento óptimo.',
    'services.more_info': 'Más Información',
    'services.explore_all': 'Explorar Todos los Servicios',

    // Benefits
    'benefits.title': 'Por Qué Elegir',
    'benefits.subtitle': 'Water Central',
    'benefits.benefit1': 'Salud para Toda la Familia',
    'benefits.benefit1_desc': 'Agua segura y pura, libre de toxinas y contaminantes. Especialmente importante para niños y embarazadas.',
    'benefits.benefit1_stats': '100% Libre de Toxinas',
    'benefits.benefit2': 'Sostenibilidad Garantizada',
    'benefits.benefit2_desc': 'Reduce drásticamente el uso de botellas de plástico. Contribuye al cuidado del medio ambiente.',
    'benefits.benefit2_stats': '250K+ Botellas Ahorradas',
    'benefits.benefit3': 'Tecnología Certificada',
    'benefits.benefit3_desc': 'Sistemas que cumplen con los estándares más estrictos de purificación y calidad de agua.',
    'benefits.benefit3_stats': 'Certificado NSF/WQA',
    'benefits.comparison': 'Transformación del Agua',
    'benefits.before': 'Agua del Grifo',
    'benefits.after': 'Agua Water Central',

    // Products
    'products.title': 'Nuestros Productos',
    'products.subtitle': 'Soluciones Completas para Toda tu Casa',
    'products.product1': 'Sistema Completo de Filtración',
    'products.product1_desc': 'Instalación completa con 10 etapas de filtración avanzada',
    'products.product2': 'Dispensador de Agua Pura',
    'products.product2_desc': 'Agua fría y caliente con purificación instantánea',
    'products.product3': 'Filtros de Reemplazo',
    'products.product3_desc': 'Filtros premium de alta duración y máxima purificación',
    'products.product4': 'Accesorios y Repuestos',
    'products.product4_desc': 'Componentes de calidad para mantener tu sistema óptimo',

    // Testimonials
    'testimonials.title': 'Lo Que Dicen Nuestros Clientes',
    'testimonials.subtitle': 'Historias Reales de Familias Reales',
    'testimonials.testimonial1': 'Water Central cambió nuestras vidas. Mis hijos tienen más energía y su piel mejoró dramáticamente.',
    'testimonials.testimonial1_author': 'María García',
    'testimonials.testimonial1_city': 'Ciudad de México',
    'testimonials.testimonial2': 'La calidad del agua es increíble. Notamos la diferencia inmediatamente. ¡Altamente recomendado!',
    'testimonials.testimonial2_author': 'Juan López',
    'testimonials.testimonial2_city': 'Guadalajara',
    'testimonials.testimonial3': 'La mejor inversión para nuestra familia. Sin más preocupaciones sobre la calidad del agua. ¡Excelente servicio!',
    'testimonials.testimonial3_author': 'Carlos Martínez',
    'testimonials.testimonial3_city': 'Monterrey',
    'testimonials.testimonial4': 'La instalación fue rápida y profesional. El equipo de soporte siempre está disponible. ¡Perfecto!',
    'testimonials.testimonial4_author': 'Ana Rodríguez',
    'testimonials.testimonial4_city': 'Cancún',

    // CTA
    'cta.title': '250,000 Familias Ya Beben',
    'cta.subtitle': 'Agua 100% Pura',
    'cta.description': '¿Tu familia será la siguiente? Solicita tu prueba de agua GRATUITA hoy. En 24 horas descubrirás exactamente qué contaminantes están en tu hogar. Sin obligación. Sin costo. Solo la verdad sobre tu agua.',
    'cta.feature1': 'Prueba Gratuita',
    'cta.feature1_desc': 'Sin costo ni obligación',
    'cta.feature2': 'Análisis Completo',
    'cta.feature2_desc': 'Identificamos todos los contaminantes',
    'cta.feature3': 'Solución Personalizada',
    'cta.feature3_desc': 'Recomendaciones adaptadas a ti',
    'cta.button': 'Solicitar Prueba Gratuita',
    'cta.trust': 'Confiado por 250K+ familias • Certificado NSF/WQA • Soporte 24/7',

    // Contact Form
    'contact.title': 'Obtén tu Prueba de Agua Gratuita',
    'contact.subtitle': 'Descubre Qué Hay en Tu Agua',
    'contact.name': 'Nombre Completo',
    'contact.email': 'Correo Electrónico',
    'contact.phone': 'Número de Teléfono',
    'contact.city': 'Ciudad',
    'contact.property': 'Tipo de Propiedad',
    'contact.property_house': 'Casa',
    'contact.property_apartment': 'Departamento',
    'contact.property_commercial': 'Comercial',
    'contact.message': 'Comentarios Adicionales',
    'contact.submit': 'Solicitar Prueba Gratuita',
    'contact.success': '¡Gracias! Nos pondremos en contacto pronto.',
    'contact.error': 'Error al enviar el formulario. Por favor, intenta de nuevo.',

    // VSL
    'vsl.title': 'Mira Cómo Funciona Water Central',
    'vsl.subtitle': 'Mira nuestro video de 2 minutos para entender la transformación',
    'vsl.play': 'Reproducir Video',

    // Floating Buttons
    'floating.whatsapp': 'Chat en WhatsApp',
    'floating.sms': 'Enviar SMS',
    'floating.call': 'Llamar',

    // Blog
    'blog.title': 'Blog de Agua Pura',
    'blog.subtitle': 'Descubre articulos sobre los beneficios del agua, salud y sostenibilidad',
    'blog.search': 'Buscar articulos...',
    'blog.all': 'Todos',
    'blog.no_results': 'No se encontraron articulos',
    'blog.view_all': 'Ver Todos los Articulos',
    'blog.read_article': 'Leer Articulo',
    'blog.back': 'Volver al Blog',
    'blog.by': 'Por',
    'blog.min_read': 'min de lectura',
    'blog.related': 'Articulos Relacionados',
    'blog.share': 'Te gusto este articulo?',
    'blog.share_desc': 'Comparte con tu familia y amigos',
    'blog.share_button': 'Compartir',
    'blog.cta_title': 'Listo para agua pura y segura?',
    'blog.cta_desc': 'Solicita una prueba gratuita de agua hoy mismo',
    'blog.cta_button': 'Solicitar Prueba Gratuita',
    'blog.not_found': 'Articulo no encontrado',

    // Footer
    'footer.services': 'Servicios',
    'footer.company': 'Empresa',
    'footer.contact': 'Contacto',
    'footer.about': 'Sobre Nosotros',
    'footer.blog': 'Blog',
    'footer.careers': 'Carreras',
    'footer.privacy': 'Política de Privacidad',
    'footer.terms': 'Términos de Servicio',
    'footer.cookies': 'Política de Cookies',
    'footer.rights': 'Todos los derechos reservados',
  },
  en: {
    // Header
    'header.inicio': 'Home',
    'header.servicios': 'Services',
    'header.beneficios': 'Benefits',
    'header.productos': 'Products',
    'header.testimonios': 'Testimonials',
    'header.blog': 'Blog',
    'header.contacto': 'Contact',
    'header.prueba': 'Free Trial',

    // Hero
    'hero.badge': '✓ NSF/WQA Certified - Guaranteed Trust',
    'hero.title1': 'The water you drink',
    'hero.title2': 'could be making',
    'hero.title3': 'your family sick',
    'hero.subtitle': 'Every drop your family drinks contains heavy metals, chlorine and bacteria. Water Central eliminates 100% of contaminants. Discover what is in your water right now with our free test.',
    'hero.cta1': 'Free Trial',
    'hero.cta2': 'Explore Services',
    'hero.stat1': '250K+',
    'hero.stat1_label': 'Protected Families',
    'hero.stat2': '10 Stages',
    'hero.stat2_label': 'Advanced Filtration',
    'hero.stat3': '100%',
    'hero.stat3_label': 'Guaranteed Purification',

    // Services
    'services.title': 'Smart Solutions',
    'services.subtitle': 'For Every Home Need',
    'services.description': 'Not all homes are the same. That is why we offer 4 personalized solutions that adapt to your specific water. Each one designed to eliminate exactly what contaminates your home.',
    'services.service1': '10-Stage Complete System',
    'services.service1_desc': 'Complete filtration for your entire home. Eliminates 100% of lead, chlorine and heavy metals.',
    'services.service2': 'Alkaline Reverse Osmosis',
    'services.service2_desc': 'Maximum purity drinking water with essential minerals. Perfect for kitchen and direct consumption.',
    'services.service3': 'Water Softeners',
    'services.service3_desc': 'Removes excess minerals and prevents scale buildup in pipes and appliances.',
    'services.service4': 'Maintenance & Support',
    'services.service4_desc': 'Complete technical service, filter changes and optimal operation guarantee.',
    'services.more_info': 'More Information',
    'services.explore_all': 'Explore All Services',

    // Benefits
    'benefits.title': 'Why Choose',
    'benefits.subtitle': 'Water Central',
    'benefits.benefit1': 'Health for the Whole Family',
    'benefits.benefit1_desc': 'Safe and pure water, free from toxins and contaminants. Especially important for children and pregnant women.',
    'benefits.benefit1_stats': '100% Toxin-Free',
    'benefits.benefit2': 'Guaranteed Sustainability',
    'benefits.benefit2_desc': 'Drastically reduces plastic bottle use. Contributes to environmental care.',
    'benefits.benefit2_stats': '250K+ Bottles Saved',
    'benefits.benefit3': 'Certified Technology',
    'benefits.benefit3_desc': 'Systems that meet the strictest water purification and quality standards.',
    'benefits.benefit3_stats': 'NSF/WQA Certified',
    'benefits.comparison': 'Water Transformation',
    'benefits.before': 'Tap Water',
    'benefits.after': 'Water Central Water',

    // Products
    'products.title': 'Our Products',
    'products.subtitle': 'Complete Solutions for Your Entire Home',
    'products.product1': 'Complete Filtration System',
    'products.product1_desc': 'Complete installation with 10 stages of advanced filtration',
    'products.product2': 'Pure Water Dispenser',
    'products.product2_desc': 'Cold and hot water with instant purification',
    'products.product3': 'Replacement Filters',
    'products.product3_desc': 'Premium filters with long-lasting and maximum purification',
    'products.product4': 'Accessories & Parts',
    'products.product4_desc': 'Quality components to keep your system optimal',

    // Testimonials
    'testimonials.title': 'What Our Customers Say',
    'testimonials.subtitle': 'Real Stories from Real Families',
    'testimonials.testimonial1': 'Water Central changed our lives. My children have more energy and their skin improved dramatically.',
    'testimonials.testimonial1_author': 'Maria Garcia',
    'testimonials.testimonial1_city': 'Mexico City',
    'testimonials.testimonial2': 'The quality of water is incredible. We noticed the difference immediately. Highly recommended!',
    'testimonials.testimonial2_author': 'Juan Lopez',
    'testimonials.testimonial2_city': 'Guadalajara',
    'testimonials.testimonial3': 'Best investment for our family. No more concerns about water quality. Excellent service!',
    'testimonials.testimonial3_author': 'Carlos Martinez',
    'testimonials.testimonial3_city': 'Monterrey',
    'testimonials.testimonial4': 'The installation was quick and professional. The support team is always available. Perfect!',
    'testimonials.testimonial4_author': 'Ana Rodriguez',
    'testimonials.testimonial4_city': 'Cancun',

    // CTA
    'cta.title': '250,000 Families Already Drinking',
    'cta.subtitle': '100% Pure Water',
    'cta.description': 'Will your family be next? Request your FREE water test today. In 24 hours you will discover exactly what contaminants are in your home. No obligation. No cost. Just the truth about your water.',
    'cta.feature1': 'Free Trial',
    'cta.feature1_desc': 'No cost or obligation',
    'cta.feature2': 'Complete Analysis',
    'cta.feature2_desc': 'We identify all contaminants',
    'cta.feature3': 'Personalized Solution',
    'cta.feature3_desc': 'Recommendations tailored to you',
    'cta.button': 'Request Free Trial',
    'cta.trust': 'Trusted by 250K+ families • Certified NSF/WQA • 24/7 Support',

    // Contact Form
    'contact.title': 'Get Your Free Water Test',
    'contact.subtitle': 'Discover What is in Your Water',
    'contact.name': 'Full Name',
    'contact.email': 'Email Address',
    'contact.phone': 'Phone Number',
    'contact.city': 'City',
    'contact.property': 'Property Type',
    'contact.property_house': 'House',
    'contact.property_apartment': 'Apartment',
    'contact.property_commercial': 'Commercial',
    'contact.message': 'Additional Comments',
    'contact.submit': 'Request Free Test',
    'contact.success': 'Thank you! We will contact you soon.',
    'contact.error': 'Error sending form. Please try again.',

    // VSL
    'vsl.title': 'See How Water Central Works',
    'vsl.subtitle': 'Watch our 2-minute video to understand the transformation',
    'vsl.play': 'Play Video',

    // Floating Buttons
    'floating.whatsapp': 'Chat on WhatsApp',
    'floating.sms': 'Send SMS',
    'floating.call': 'Call Us',

    // Blog
    'blog.title': 'Pure Water Blog',
    'blog.subtitle': 'Discover articles about water benefits, health and sustainability',
    'blog.search': 'Search articles...',
    'blog.all': 'All',
    'blog.no_results': 'No articles found',
    'blog.view_all': 'View All Articles',
    'blog.read_article': 'Read Article',
    'blog.back': 'Back to Blog',
    'blog.by': 'By',
    'blog.min_read': 'min read',
    'blog.related': 'Related Articles',
    'blog.share': 'Did you like this article?',
    'blog.share_desc': 'Share with your family and friends',
    'blog.share_button': 'Share',
    'blog.cta_title': 'Ready for pure and safe water?',
    'blog.cta_desc': 'Request a free water test today',
    'blog.cta_button': 'Request Free Test',
    'blog.not_found': 'Article not found',

    // Footer
    'footer.services': 'Services',
    'footer.company': 'Company',
    'footer.contact': 'Contact',
    'footer.about': 'About Us',
    'footer.blog': 'Blog',
    'footer.careers': 'Careers',
    'footer.privacy': 'Privacy Policy',
    'footer.terms': 'Terms of Service',
    'footer.cookies': 'Cookie Policy',
    'footer.rights': 'All rights reserved',
  },
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>('en');
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // Detectar idioma solo en cliente
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('language');
        if (saved === 'es' || saved === 'en') {
          setLanguageState(saved);
        } else {
          const browserLang = navigator.language.split('-')[0];
          const detectedLang = browserLang === 'es' ? 'es' : 'en'; // Default EN for American audience
          setLanguageState(detectedLang);
        }
      } catch (e) {
        // localStorage no disponible
      }
    }
    setIsInitialized(true);
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('language', lang);
      } catch (e) {
        // localStorage no disponible
      }
    }
  };

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['es']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    // Retornar un valor por defecto en lugar de lanzar error
    return {
      language: 'en' as Language,
      setLanguage: () => {},
      t: (key: string) => key,
    };
  }
  return context;
}
