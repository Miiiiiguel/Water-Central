'use client';

import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Calendar, Clock, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { blogArticles, blogCategories } from '@/data/blogData';

export default function Blog() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [, navigate] = useLocation();
  const { language, t } = useLanguage();

  const filteredArticles = useMemo(() => {
    return blogArticles.filter((article) => {
      const searchLower = searchTerm.toLowerCase();
      const titleMatch = language === 'es'
        ? article.title.toLowerCase().includes(searchLower)
        : article.titleEn.toLowerCase().includes(searchLower);
      const excerptMatch = language === 'es'
        ? article.excerpt.toLowerCase().includes(searchLower)
        : article.excerptEn.toLowerCase().includes(searchLower);
      const categoryMatch = !selectedCategory || article.category === selectedCategory;

      return (titleMatch || excerptMatch) && categoryMatch;
    });
  }, [searchTerm, selectedCategory, language]);

  const getFormattedDate = (dateString: string) => {
    const date = new Date(dateString);
    return language === 'es'
      ? date.toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })
      : date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white pt-24 pb-20">
      {/* Header */}
      <div className="container mb-16">
        <div className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold text-primary mb-4">
            {t('blog.title')}
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {t('blog.subtitle')}
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <Input
              type="text"
              placeholder={t('blog.search')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 py-3 text-lg border-2 border-gray-200 focus:border-cyan-500 rounded-lg"
            />
          </div>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 justify-center mb-12">
            <Button
              onClick={() => setSelectedCategory(null)}
              variant={selectedCategory === null ? 'default' : 'outline'}
              className={`${
                selectedCategory === null
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                  : 'border-2 border-gray-300 text-gray-700 hover:border-cyan-500'
              }`}
            >
              {t('blog.all')}
          </Button>
          {blogCategories.map((category) => (
            <Button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              variant={selectedCategory === category.id ? 'default' : 'outline'}
              className={`${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white'
                  : 'border-2 border-gray-300 text-gray-700 hover:border-cyan-500'
              }`}
            >
              {category.icon} {language === 'es' ? category.name : category.nameEn}
            </Button>
          ))}
        </div>
      </div>

      {/* Articles Grid */}
      <div className="container">
        {filteredArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArticles.map((article) => (
              <div
                key={article.id}
                onClick={() => navigate(`/blog/${article.slug}`)}
                className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer border border-gray-200 hover:border-cyan-500"
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden bg-gradient-to-br from-cyan-500/10 to-blue-500/10">
                  <img
                    src={article.image}
                    alt={language === 'es' ? article.title : article.titleEn}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                  <div className="absolute top-4 right-4">
                  <span className="bg-cyan-500/90 text-white px-3 py-1 rounded-full text-sm font-semibold">
                    {language === 'es'
                      ? blogCategories.find((c) => c.id === article.category)?.name
                      : blogCategories.find((c) => c.id === article.category)?.nameEn}
                  </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-primary mb-3 line-clamp-2 group-hover:text-cyan-600 transition-colors">
                    {language === 'es' ? article.title : article.titleEn}
                  </h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                    {language === 'es' ? article.excerpt : article.excerptEn}
                  </p>

                  {/* Meta Info */}
                  <div className="flex items-center gap-4 text-xs text-gray-500 mb-4 pb-4 border-b border-gray-200">
                    <div className="flex items-center gap-1">
                      <Calendar size={14} />
                      {getFormattedDate(article.date)}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock size={14} />
                      {article.readTime} {t('blog.min_read')}
                    </div>
                  </div>

                  {/* Author */}
                  <div className="text-sm text-gray-600 mb-4">
                    {t('blog.by')} <span className="font-semibold text-primary">{article.author}</span>
                  </div>

                  {/* Read More Button */}
                  <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white border-0 group/btn flex items-center justify-center gap-2">
                    {t('blog.read_article')}
                    <ChevronRight size={16} className="group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-xl text-gray-600 mb-4">
              {t('blog.no_results')}
            </p>
            <Button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory(null);
              }}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white"
            >
              {t('blog.view_all')}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
