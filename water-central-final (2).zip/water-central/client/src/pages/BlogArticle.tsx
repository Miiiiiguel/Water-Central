'use client';

import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Calendar, Clock, User, ArrowLeft, Share2 } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { blogArticles, blogCategories } from '@/data/blogData';

export default function BlogArticle() {
  const [location, navigate] = useLocation();
  const { language, t } = useLanguage();

  // Extract slug from URL
  const slug = location.split('/').pop();
  const article = blogArticles.find((a) => a.slug === slug);

  if (!article) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-white">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-primary mb-4">
            {t('blog.not_found')}
          </h1>
          <Button
            onClick={() => navigate('/blog')}
            className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white"
          >
            {t('blog.back')}
          </Button>
        </div>
      </div>
    );
  }

  const getFormattedDate = (dateString: string) => {
    const date = new Date(dateString);
    return language === 'es'
      ? date.toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })
      : date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const category = blogCategories.find((c) => c.id === article.category);
  const content = language === 'es' ? article.content : article.contentEn;

  return (
    <div className="min-h-screen bg-white pt-24 pb-20">
      {/* Back Button */}
      <div className="container mb-8">
        <Button
          onClick={() => navigate('/blog')}
          variant="outline"
          className="border-2 border-gray-300 text-gray-700 hover:border-cyan-500 flex items-center gap-2"
        >
          <ArrowLeft size={18} />
          {t('blog.back')}
        </Button>
      </div>

      {/* Hero Image */}
      <div className="w-full h-96 md:h-[500px] overflow-hidden bg-gradient-to-br from-cyan-500/10 to-blue-500/10 mb-12">
        <img
          src={article.image}
          alt={language === 'es' ? article.title : article.titleEn}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Article Content */}
      <article className="container max-w-3xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <span className="bg-cyan-500/20 text-cyan-700 px-4 py-1 rounded-full text-sm font-semibold">
              {category?.icon} {language === 'es' ? category?.name : category?.nameEn}
            </span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6">
            {language === 'es' ? article.title : article.titleEn}
          </h1>

          {/* Meta Info */}
          <div className="flex flex-wrap items-center gap-6 text-gray-600 pb-6 border-b-2 border-gray-200">
            <div className="flex items-center gap-2">
              <User size={18} className="text-cyan-500" />
              <span>{article.author}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar size={18} className="text-cyan-500" />
              <span>{getFormattedDate(article.date)}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock size={18} className="text-cyan-500" />
              <span>
                {article.readTime} {t('blog.min_read')}
              </span>
            </div>
          </div>
        </div>

        {/* Article Body */}
        <div className="prose prose-lg max-w-none mb-12">
          {content.split('\n\n').map((paragraph, index) => {
            if (paragraph.startsWith('##')) {
              return (
                <h2 key={index} className="text-3xl font-bold text-primary mt-8 mb-4">
                  {paragraph.replace('## ', '')}
                </h2>
              );
            }
            if (paragraph.startsWith('###')) {
              return (
                <h3 key={index} className="text-2xl font-bold text-primary/80 mt-6 mb-3">
                  {paragraph.replace('### ', '')}
                </h3>
              );
            }
            if (paragraph.startsWith('- ')) {
              const items = paragraph.split('\n').filter((item) => item.startsWith('- '));
              return (
                <ul key={index} className="list-disc list-inside space-y-2 text-gray-700 mb-4">
                  {items.map((item, i) => (
                    <li key={i} className="text-base leading-relaxed">
                      {item.replace('- ', '')}
                    </li>
                  ))}
                </ul>
              );
            }
            if (paragraph.startsWith('✓')) {
              const items = paragraph.split('\n').filter((item) => item.startsWith('✓'));
              return (
                <ul key={index} className="space-y-2 text-gray-700 mb-4">
                  {items.map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-base">
                      <span className="text-cyan-500 font-bold">✓</span>
                      {item.replace('✓ ', '')}
                    </li>
                  ))}
                </ul>
              );
            }
            if (paragraph.trim()) {
              return (
                <p key={index} className="text-gray-700 leading-relaxed mb-4 text-lg">
                  {paragraph}
                </p>
              );
            }
            return null;
          })}
        </div>

        {/* Share Section */}
        <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-xl p-8 mb-12">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h3 className="text-xl font-bold text-primary mb-2">
                {t('blog.share')}
              </h3>
              <p className="text-gray-600">
                {t('blog.share_desc')}
              </p>
            </div>
            <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-600 hover:to-blue-700 flex items-center gap-2">
              <Share2 size={18} />
              {t('blog.share_button')}
            </Button>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">
            {t('blog.cta_title')}
          </h3>
          <p className="text-cyan-100 mb-6 text-lg">
            {t('blog.cta_desc')}
          </p>
          <Button
            onClick={() => navigate('/')}
            className="bg-white text-cyan-600 hover:bg-gray-100 font-bold px-8 py-3 text-lg"
          >
            {t('blog.cta_button')}
          </Button>
        </div>
      </article>

      {/* Related Articles */}
      <div className="container mt-20">
        <h2 className="text-3xl font-bold text-primary mb-8 text-center">
          {t('blog.related')}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogArticles
            .filter((a) => a.id !== article.id && a.category === article.category)
            .slice(0, 3)
            .map((relatedArticle) => (
              <div
                key={relatedArticle.id}
                onClick={() => navigate(`/blog/${relatedArticle.slug}`)}
                className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer border border-gray-200 hover:border-cyan-500"
              >
                <div className="relative h-40 overflow-hidden bg-gradient-to-br from-cyan-500/10 to-blue-500/10">
                  <img
                    src={relatedArticle.image}
                    alt={language === 'es' ? relatedArticle.title : relatedArticle.titleEn}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-primary line-clamp-2 group-hover:text-cyan-600 transition-colors">
                    {language === 'es' ? relatedArticle.title : relatedArticle.titleEn}
                  </h3>
                  <p className="text-sm text-gray-600 mt-2 line-clamp-2">
                    {language === 'es' ? relatedArticle.excerpt : relatedArticle.excerptEn}
                  </p>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
