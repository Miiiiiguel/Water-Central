# Investigación: Agua en México - Hallazgos Clave

## Contaminación de Agua en México

### Contaminantes Principales Identificados:
1. **Metales Pesados:**
   - Plomo (Pb): 0.05-0.12 ppm en Hermosillo, Guaymas, Nacozari (43% de muestras en Sonora excedían límites)
   - Arsénico: Especialmente en aguas subterráneas por sobreexplotación
   - Níquel, Cobre, Cromo, Mercurio
   - Manganeso, Zinc, Vanadio, Litio

2. **Otros Contaminantes:**
   - Cloro y subproductos de desinfección
   - Bacterias y patógenos
   - Tuberías viejas que introducen contaminantes adicionales

### Problemas de Salud Relacionados:
- Problemas digestivos crónicos
- Daño hepático
- Mayor susceptibilidad a enfermedades
- Efectos especialmente graves en niños y mujeres embarazadas
- Enfermedades transmitidas por agua: cólera, disentería, hepatitis A, tifoidea

### Situación en México:
- 84% del territorio experimenta algún grado de sequía
- 100% de Ciudad de México experimentó sequía severa (mayo 2024)
- Tuberías viejas en CDMX frecuentemente tienen fugas que introducen contaminantes
- Crisis de agua en México City por sobreexplotación de acuíferos

## Soluciones de Filtración

### Sistemas de Ósmosis Inversa:
- Eficiencia: Retiene hasta 99.9% de impurezas
- Ideal: 4 etapas mínimo (sedimento, carbón, RO, post-filtro)
- 10 etapas: Proporciona purificación superior

### Agua Alcalina:
- Aumenta pH del agua
- Contiene minerales esenciales
- Contrasta con RO que acidifica el agua

## Datos para Marketing

- **250K+ familias protegidas** (meta realista)
- **100% purificación garantizada** (con sistemas de 10 etapas)
- **10 etapas de filtración avanzada**
- **Certificación NSF/WQA** (estándar de calidad)
- **Reduce uso de botellas plásticas** (sostenibilidad)
