# Propuesta de Diseño Visual: Water Central

## Filosofía de Diseño Elegida: "Minimalismo Fluido Contemporáneo"

### Design Movement
**Minimalismo Contemporáneo + Fluidez Orgánica**
Inspirado en el diseño nórdico moderno y las interfaces de tecnología de punta (Apple, Tesla), pero con elementos orgánicos que evocan el movimiento del agua.

---

## Core Principles

1. **Claridad Radical:** Cada elemento tiene un propósito claro. Sin decoración innecesaria. El contenido respira.
2. **Fluidez Visual:** Las transiciones entre secciones son suaves y orgánicas, como el agua fluyendo. Uso de curvas sutiles en lugar de ángulos rectos.
3. **Jerarquía Tipográfica Fuerte:** Contrastes marcados entre títulos (grandes, audaces) y cuerpo (ligero, legible). La tipografía comunica la importancia.
4. **Confianza a través de Espacio:** Amplios márgenes, padding generoso y espacios en blanco transmiten profesionalismo y seguridad (crucial para servicios de salud/agua).

---

## Color Philosophy

**Paleta Primaria:**
- **Azul Profundo (#1E3A8A):** Confianza, tecnología, pureza. Usado en CTAs y elementos clave.
- **Azul Cian Claro (#06B6D4):** Energía, frescura, agua en movimiento. Acentos y highlights.
- **Blanco Puro (#FFFFFF):** Limpieza, claridad, espacio.
- **Gris Neutro (#6B7280 - #9CA3AF):** Texto secundario, bordes sutiles, fondos suaves.
- **Gris Oscuro (#1F2937):** Texto principal, máxima legibilidad.

**Razonamiento Emocional:**
- Los azules evocan agua, cielo limpio y confianza médica.
- El blanco y grises mantienen la sensación de pureza y profesionalismo.
- Sin colores cálidos que distraigan; todo comunica limpieza y tecnología.

---

## Layout Paradigm

**Estructura Asimétrica Moderna:**
- Hero Section: Imagen/video de fondo con overlay de gradiente sutil (azul profundo a transparente).
- Secciones alternadas: Contenido a la izquierda + Visual a la derecha, luego invertido.
- Uso de "Diagonal Dividers" (SVG con ángulos suaves) para separar secciones sin líneas rectas.
- Grid de 12 columnas con márgenes amplios (no centrado, sino con asimetría intencional).

---

## Signature Elements

1. **Iconografía Lineal Minimalista:** Iconos de trazo fino (2px) que representan procesos de filtración. Animados en scroll.
2. **Líneas Fluidas (SVG Dividers):** Separadores ondulados entre secciones que evocan el movimiento del agua.
3. **Tarjetas con Sombra Suave:** Cards con `box-shadow: 0 4px 20px rgba(30, 58, 138, 0.08)` para profundidad sin peso visual.

---

## Interaction Philosophy

- **Micro-interacciones Sutiles:** Botones cambian de color suavemente (no saltos abruptos).
- **Scroll Animations:** Elementos aparecen con fade-in suave al hacer scroll.
- **Hover Effects:** Los elementos interactivos tienen un ligero cambio de escala (1.02x) y sombra aumentada.
- **Formularios Inteligentes:** Campos con borde inferior animado (solo el borde inferior, no toda la caja).

---

## Animation Guidelines

- **Duración:** 300-400ms para transiciones, 600-800ms para entrada de secciones.
- **Easing:** `cubic-bezier(0.4, 0, 0.2, 1)` (Material Design Standard Easing) para fluidez.
- **Scroll Animations:** Fade-in + pequeño desplazamiento vertical (20px) al entrar en viewport.
- **Botones:** Cambio de color + ligera elevación en hover.

---

## Typography System

**Fuentes:**
- **Display (Títulos):** Montserrat Bold (700) - Moderna, geométrica, profesional.
- **Body (Texto):** Inter Light/Regular (300/400) - Limpia, altamente legible, minimalista.

**Jerarquía:**
- **H1 (Hero):** 56px Montserrat 700, line-height 1.2, color Azul Profundo.
- **H2 (Secciones):** 36px Montserrat 700, color Azul Profundo.
- **H3 (Subsecciones):** 24px Montserrat 600, color Gris Oscuro.
- **Body:** 16px Inter 400, color Gris Oscuro, line-height 1.6.
- **Small Text:** 14px Inter 300, color Gris Medio.

---

## Resumen Visual

Este diseño comunica: **Tecnología Avanzada + Pureza + Confianza + Modernidad**

No es corporativo ni aburrido, sino contemporáneo, limpio y orientado a la conversión.
