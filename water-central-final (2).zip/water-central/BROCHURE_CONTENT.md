# Brochure Content - The Kure Water / Water Central

## 10 Stage Purification Process (from brochure pages 1-2)

1. Softening Resin - 10% Resin removes hardness in water
2. Catalytic/Coconut Shell Carbon - Reduction of taste, odors, chlorine and other chemicals
3. KDF Media - Removes chlorine/lead and other heavy metals
4. PH Alkaline Media - Regulates the PH of water, resulting in alkaline water
5. Gravel - High grade sediment reduction, acts like a clarifier
6. Far-Infra Red Rays - Promote growth and health of cells
7. Oxidation Reduction Potential - Attacks dangerous free radicals
8. Tourmaline - Boosts immune system and promotes detoxification
9. Maifan Ceramic Balls - Removes lead, arsenic, heavy metals, chlorine
10. Minerals - Activating, purifying, and mineralizing drinking water

## #1 Valve in the World
- State of the Art Control head for residential and commercial
- Double backwash to ensure media is clean
- Highly efficient for less salt & water usage
- Power cell memory retains all settings for weeks

## Page 3 - Company Info
- U.S.A. Locations: Texas, Florida, Puerto Rico
- Toll Free: 800-748-4189
- Website: www.thekurewater.com
- Certifications: CE, Water Quality Association, BBB

## Page 4 - 6-Stage Alkaline Water System
- GE Membrane, Carbon Block, GAC, Sediment
- Made in USA
- Premium Reverse Osmosis Drinking Water System
- Naturally Energized Alkaline Water

## Page 5 - Alkaline Benefits
- Blood PH of 7.365 essential
- Raises pH to 10.5 (vs calcite filters only 7.5)
- Active Oxygen / Free Radicals info
- Proud to be serving 55,000+ customers
- Contact: The Kure Water INC, +1800-748-4189

## Product Images Available
- PNG-tank-10-Steps-3-scaled.webp (black tank with 10 stages)
- WhatsApp-Image-2026-02-20-at-22.33.58.jpeg (stainless steel tank)
- thekurebrochure.pdf (5-page brochure)
